package com.example.pocketoptometrist

import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.io.IOException


import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream

class ExamActivity : AppCompatActivity() {

    // Global answer list, index 0 is 'L' or 'R' for appropriate eye
    private val globalAnswerList = ArrayList<String>()

    // play audio recordings
    private var mediaPlayer: MediaPlayer? = null
    // record audio
    private var mediaRecorder: MediaRecorder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exam)


        // Retrieve the selected switch text from the Intent
        val selectedSwitchText = intent.getStringExtra("selectedSwitchText")
        if (selectedSwitchText != null) {
            globalAnswerList.add(selectedSwitchText)
        }


        // Check for microphone
        if (isMicrophonePresent()) {

            // Play exam prompts
            // and get recording for each prompt

            // 1
            playAudioRecording1()
                startAudioRecording()


            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 2
                playAudioRecording2()
            }, 7500)
            startAudioRecording()



            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 3
                playAudioRecording3()
            }, 15000)
            startAudioRecording()



            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 4
                playAudioRecording4()
            }, 22500)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 5
                playAudioRecording5()
            }, 30000)
            startAudioRecording()


            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 6
                playAudioRecording6()
            }, 37500)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 7
                playAudioRecording7()
            }, 45000)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 8
                playAudioRecording8()
            }, 52500)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 9
                playAudioRecording9()
            }, 60000)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                // 10
                playAudioRecording10()
            }, 67500)
            startAudioRecording()

            // Add a 7.5-second delay
            Handler(Looper.getMainLooper()).postDelayed({
                //11
                playAudioRecording11()
            }, 75000)
            startAudioRecording()

            // Add a 7.5-second delay after the last prompt
            Handler(Looper.getMainLooper()).postDelayed({
                // Load a 3rd activity class and pass global answer list
                val intent = Intent(this, ThirdActivity::class.java)
                intent.putStringArrayListExtra("answerList", globalAnswerList)
                startActivity(intent)
            }, 82500)

        }
    }

    private fun isMicrophonePresent(): Boolean {
        return packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)
    }

//1
    private fun playAudioRecording1() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line1}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 1 prompt
        mediaPlayer.start()
    }
//2
    private fun playAudioRecording2() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line2}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }

    //3
    private fun playAudioRecording3() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line3}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }

//4
    private fun playAudioRecording4() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line4}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }

    //5
    private fun playAudioRecording5() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line5}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
//6
    private fun playAudioRecording6() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line6}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
//7
    private fun playAudioRecording7() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line7}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
//8
    private fun playAudioRecording8() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line8}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
//9
    private fun playAudioRecording9() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line9}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
//10
    private fun playAudioRecording10() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line10}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }
    //11
    private fun playAudioRecording11() {
        val audioUri: Uri = Uri.parse("android.resource://${packageName}/${R.raw.line11}")

        val mediaPlayer = MediaPlayer.create(this, audioUri)

        mediaPlayer.setOnCompletionListener {
            // Release the MediaPlayer when playback is complete
            mediaPlayer.release()
        }
        // play line 2 prompt
        mediaPlayer.start()
    }

    private fun startAudioRecording() {
        mediaRecorder = MediaRecorder()

        // Set the audio source to the microphone
        mediaRecorder?.setAudioSource(MediaRecorder.AudioSource.MIC)

        // Set the output format and encoder
        mediaRecorder?.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
        mediaRecorder?.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)

        try {

            // Prepare and start recording
            mediaRecorder?.prepare()
            mediaRecorder?.start()

            // Stop recording after 5 seconds
            android.os.Handler().postDelayed({
                stopRecording()
            }, 5000)
        } catch (e: IOException) {
            // Handle exceptions
            e.printStackTrace()
        }
    }

    private fun stopRecording() {
        mediaRecorder?.stop()
        mediaRecorder?.release()
        mediaRecorder = null

        // Get the recorded audio data
        val recordedAudioData: ByteArray? = getRecordedAudioData()

        // Pass the recorded audio data
        recordedAudioData?.let { convertAudioToString(it) }
    }

    private fun getRecordedAudioData(): ByteArray? {

        val audioDataBuffer = ByteArrayOutputStream()
        return audioDataBuffer.toByteArray()
    }

    private fun convertAudioToString(audioData: ByteArray) {
        val audioString = String(audioData)
        // add converted audio answer to global answer list
        globalAnswerList.add(audioString)
    }
    override fun onDestroy() {
        super.onDestroy()
        // Release resources when the activity is destroyed
        mediaRecorder?.release()
    }
}







