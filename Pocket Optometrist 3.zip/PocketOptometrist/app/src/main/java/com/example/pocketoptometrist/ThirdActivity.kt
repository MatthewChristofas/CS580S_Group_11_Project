package com.example.pocketoptometrist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.widget.SwitchCompat

class ThirdActivity : AppCompatActivity() {

   // left eye score
    private var globalLeftScore: Int = 0
    // right eye score
    private var globalRightScore: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val doneActivityBtn: Button = findViewById (R.id.doneBtn)
        val startActivityBtn: Button = findViewById(R.id.startBtn)
        val switch1: SwitchCompat = findViewById(R.id.switch1)

        // Retrieve the answerList from the Intent
        val answerList = intent.getStringArrayListExtra("answerList")

        compareAnswers(answerList);



        doneActivityBtn.setOnClickListener() {
            val intent = Intent(this, FourthActivity::class.java)

            // pass globalLeftScore and globalRightScore to 4th activity class
            intent.putExtra("leftScore", globalLeftScore)
            intent.putExtra("rightScore", globalRightScore)

            startActivity(intent)
        }

        // Add OnClickListener for the startBtn
        startActivityBtn.setOnClickListener {
            // Pass the selected text of the switch to ExamActivity (for left or right eye)
            val switchText = if (switch1.isChecked) "L" else "R"

            val intent = Intent(this, ExamActivity::class.java)
            intent.putExtra("selectedSwitchText", switchText)
            startActivity(intent)
        }


    }
    private fun compareAnswers(answerList: List<String>?) {
        if (answerList != null && answerList.size == 11) {

            // LEFT EYE
            if (answerList[0] == "L") {

                // passed line 1
                if (answerList[1] == "E") {

                    // passed line 2
                    if (answerList[2] == "FP") {

                        // passed line 3
                        if (answerList[3] == "TOZ") {

                            // passed line 4
                            if (answerList[4] == "LPED") {

                                // passed line 5
                                if (answerList[5] == "PECFD") {

                                    // passed line 6
                                    if (answerList[6] == "EDFCZP") {

                                        // passed line 7
                                        if (answerList[7] == "FELOPZD") {

                                            // passed line 8
                                            if (answerList[8] == "DEFPOTEC") {

                                                // passed line 9
                                                if (answerList[9] == "LEFODPCT") {

                                                    // passed line 10
                                                    if (answerList[10] == "FDPLTCEO") {

                                                        // passed line 11
                                                        if (answerList[10] == "PEZOLCFTD") {
                                                            globalLeftScore = 20 / 20
                                                        } else {
                                                            // failed line 11
                                                            globalLeftScore = 20 / 20
                                                        }
                                                    } else {
                                                        // failed line 10
                                                        globalLeftScore = 20 / 20
                                                    }
                                                } else {
                                                    // failed line 9
                                                    globalLeftScore = 20 / 20
                                                }
                                            } else {
                                                // failed line 8
                                                globalLeftScore = 20 / 25
                                            }
                                        } else {
                                            // failed line 7
                                            globalLeftScore = 20 / 30
                                        }
                                    } else {
                                        // failed line 6
                                        globalLeftScore = 20 / 40
                                    }
                                } else {
                                    // failed line 5
                                    globalLeftScore = 20 / 50
                                }
                            } else {
                                // failed line 4
                                globalLeftScore = 20 / 70
                            }
                        } else {
                            // failed line 3
                            globalLeftScore = 20 / 100
                        }
                    } else {
                        // failed line 2
                        globalLeftScore = 20 / 200
                    }
                } else {
                    // failed line 1
                    globalLeftScore = 0
                }
            }


            // RIGHT EYE
            if (answerList[0] == "R") {

                // passed line 1
                if (answerList[1] == "E") {

                    // passed line 2
                    if (answerList[2] == "FP") {

                        // passed line 3
                        if (answerList[3] == "TOZ") {

                            // passed line 4
                            if (answerList[4] == "LPED") {

                                // passed line 5
                                if (answerList[5] == "PECFD") {

                                    // passed line 6
                                    if (answerList[6] == "EDFCZP") {

                                        // passed line 7
                                        if (answerList[7] == "FELOPZD") {

                                            // passed line 8
                                            if (answerList[8] == "DEFPOTEC") {

                                                // passed line 9
                                                if (answerList[9] == "LEFODPCT") {

                                                    // passed line 10
                                                    if (answerList[10] == "FDPLTCEO") {

                                                        // passed line 11
                                                        if (answerList[10] == "PEZOLCFTD") {
                                                            globalRightScore = 20 / 20
                                                        } else {
                                                            // failed line 11
                                                            globalRightScore = 20 / 20
                                                        }
                                                    } else {
                                                        // failed line 10
                                                        globalRightScore = 20 / 20
                                                    }
                                                } else {
                                                    // failed line 9
                                                    globalRightScore = 20 / 20
                                                }
                                            } else {
                                                // failed line 8
                                                globalRightScore = 20 / 25
                                            }
                                        } else {
                                            // failed line 7
                                            globalRightScore = 20 / 30
                                        }
                                    } else {
                                        // failed line 6
                                        globalRightScore = 20 / 40
                                    }
                                } else {
                                    // failed line 5
                                    globalRightScore = 20 / 50
                                }
                            } else {
                                // failed line 4
                                globalRightScore = 20 / 70
                            }
                        } else {
                            // failed line 3
                            globalRightScore = 20 / 100
                        }
                    } else {
                        // failed line 2
                        globalRightScore = 20 / 200
                    }
                } else {
                    // failed line 1
                    globalRightScore = 0
                }
            }


        }
    }

}