package com.example.pocketoptometrist

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class FourthActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fourth)

        // Retrieve the left and right scores from the Intent
        val leftScore = intent.getIntExtra("leftScore", 0)
        val rightScore = intent.getIntExtra("rightScore", 0)

        val retestActivityBtn: Button = findViewById (R.id.restartBtn)

        retestActivityBtn.setOnClickListener() {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val leftEye: TextView = findViewById(R.id.leftEyeScore)
        val rightEye: TextView = findViewById(R.id.rightEyeScore)
        val averageTxt: TextView = findViewById(R.id.averageEyeScore)
        val prescript: TextView = findViewById(R.id.prescription)


        val randomValue1 = (2..20).random() * 10
        val randomValue2 = (2..20).random() * 10

        val average = (randomValue1 + randomValue2) / 2


        leftEye.text = "20/$randomValue1"
        rightEye.text = "20/$randomValue2"
        averageTxt.text = "20/$average"
        prescript.text = "20/$average"
    }
}